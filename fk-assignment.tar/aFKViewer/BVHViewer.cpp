#include <string>
#include "BVHViewer.h"
#include "GL/glew.h"
#include "GL/glut.h"
#include <algorithm>
#include <AntTweakBar.h>

BVHViewer::BVHViewer() : mBVHController(), mDrawer()
{
}

BVHViewer::~BVHViewer()
{
}

void BVHViewer::load(const std::string& filename)
{
    loadMotion(filename);
}

void BVHViewer::loadMotion(const std::string& filename)
{
    mBVHController.load(filename);
    mFilename = pruneName(filename);
}

void BVHViewer::initializeGui()
{
    ABasicViewer::initializeGui();
}

void BVHViewer::onStepBack()
{
    double dt = 1.0/mBVHController.getFramerate();
    mCurrentFrame = mCurrentFrame - 1;
    if (mCurrentFrame < 0) mCurrentFrame = mBVHController.getNumKeys() - 1;
    mCurrentTime = mCurrentFrame * dt;
}

void BVHViewer::onStepForward()
{
    double dt = 1.0/mBVHController.getFramerate();
    mCurrentFrame = (mCurrentFrame + 1) % mBVHController.getNumKeys();
    mCurrentTime = mCurrentFrame * dt;
}

void BVHViewer::onTimer(int value)
{
    ABasicViewer::onTimer(value);
    mBVHController.update(mCurrentTime);
    mCurrentFrame = mBVHController.getFrame(mCurrentTime);
}

void BVHViewer::draw3DView()
{
    glViewport(0, 0, (GLsizei)mWindowWidth, (GLsizei)mWindowHeight);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE); // Draw the front face only, except for the texts and lights.
    glEnable(GL_LIGHTING);

    // Set the view to the current camera settings.
    mCamera.draw();

    GLfloat pos[4];
    pos[0] = mCamera.getPosition()[0];
    pos[1] = mCamera.getPosition()[1];
    pos[2] = mCamera.getPosition()[2];
    pos[3] = 1.0;
    glLightfv(GL_LIGHT0, GL_POSITION, pos);

    mDrawer.draw(mBVHController.getSkeleton());

    glDisable(GL_LIGHTING);
    displayGrid();
}

