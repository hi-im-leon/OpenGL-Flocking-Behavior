#include <string>
#include <vector>
extern std::vector<std::string> GetFilenamesInDir(const std::string& dirname);
extern std::string PromptToLoad();
extern std::string PromptToLoadDir();

